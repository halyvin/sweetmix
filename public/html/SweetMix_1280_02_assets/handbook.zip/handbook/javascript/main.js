$(document).ready(function(){
	 $('#login').bind('click', function(){
	 	$('.login').show();
	 });
	 $('#register').bind('click', function(){
	 	$('.login').hide();
	 	$('#overlay').show().animate({'opacity':1}, 300);
	 });
	$('#overlay').bind('click', function(){
	 	$('#overlay').animate({'opacity':0}, 300, function(){
	 		$('#overlay').hide();
	 	});
	 });
});